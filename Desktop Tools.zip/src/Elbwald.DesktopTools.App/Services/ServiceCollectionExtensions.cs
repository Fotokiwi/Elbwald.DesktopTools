using Elbwald.DesktopTools.Core.Modules;
using Microsoft.Extensions.DependencyInjection;

namespace Elbwald.DesktopTools.App.Services;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDesktopTools(
        this IServiceCollection services)
    {
        services.AddSingleton<IModuleRegistry, ModuleRegistry>();
        services.AddSingleton<IModuleLoader, ModuleLoader>();

        return services;
    }
}
