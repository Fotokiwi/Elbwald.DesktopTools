using System.Collections.Generic;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;
using Elbwald.DesktopTools.Contracts.Modules;
using Elbwald.DesktopTools.Core.Modules;

namespace Elbwald.DesktopTools.App.ViewModels;

public partial class MainWindowViewModel : ObservableObject
{
    public MainWindowViewModel(IModuleRegistry moduleRegistry)
    {
        Modules = moduleRegistry.Modules
            .Select(module => module.GetDescriptor())
            .OrderBy(module => module.Name)
            .ToArray();

        Greeting = Modules.Count == 1
            ? "Elbwald Digital – Desktop Tools · 1 Modul geladen"
            : $"Elbwald Digital – Desktop Tools · {Modules.Count} Module geladen";
    }

    public string Greeting { get; }

    public IReadOnlyList<ToolModuleDescriptor> Modules { get; }
}
