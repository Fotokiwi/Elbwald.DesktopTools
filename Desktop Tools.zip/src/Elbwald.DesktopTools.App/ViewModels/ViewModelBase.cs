﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Elbwald.DesktopTools.App.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}