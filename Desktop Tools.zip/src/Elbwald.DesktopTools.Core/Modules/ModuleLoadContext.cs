using System.Reflection;
using System.Runtime.Loader;

namespace Elbwald.DesktopTools.Core.Modules;

internal sealed class ModuleLoadContext : AssemblyLoadContext
{
    private readonly AssemblyDependencyResolver _resolver;

    public ModuleLoadContext(string moduleAssemblyPath)
        : base(isCollectible: false)
    {
        _resolver = new AssemblyDependencyResolver(moduleAssemblyPath);
    }

    protected override Assembly? Load(AssemblyName assemblyName)
    {
        if (ShouldUseDefaultContext(assemblyName))
        {
            return AssemblyLoadContext.Default.LoadFromAssemblyName(assemblyName);
        }

        var assemblyPath = _resolver.ResolveAssemblyToPath(assemblyName);

        return assemblyPath is null
            ? null
            : LoadFromAssemblyPath(assemblyPath);
    }

    protected override nint LoadUnmanagedDll(string unmanagedDllName)
    {
        var libraryPath = _resolver.ResolveUnmanagedDllToPath(unmanagedDllName);

        return libraryPath is null
            ? nint.Zero
            : LoadUnmanagedDllFromPath(libraryPath);
    }

    private static bool ShouldUseDefaultContext(AssemblyName assemblyName)
    {
        var name = assemblyName.Name ?? string.Empty;

        return name.Equals(
                   "Elbwald.DesktopTools.Contracts",
                   StringComparison.OrdinalIgnoreCase)
               || name.Equals(
                   "Elbwald.DesktopTools.UI",
                   StringComparison.OrdinalIgnoreCase)
               || name.Equals(
                   "CommunityToolkit.Mvvm",
                   StringComparison.OrdinalIgnoreCase)
               || name.StartsWith(
                   "Avalonia",
                   StringComparison.OrdinalIgnoreCase)
               || name.StartsWith(
                   "Microsoft.Extensions.",
                   StringComparison.OrdinalIgnoreCase);
    }
}
