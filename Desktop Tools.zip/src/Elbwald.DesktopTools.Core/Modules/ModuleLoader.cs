using System.Reflection;
using System.Text.Json;
using Elbwald.DesktopTools.Contracts.Modules;

namespace Elbwald.DesktopTools.Core.Modules;

public sealed class ModuleLoader : IModuleLoader
{
    public const int SupportedApiVersion = 1;

    private readonly IModuleRegistry _registry;
    private readonly List<ModuleLoadContext> _loadContexts = [];

    public ModuleLoader(IModuleRegistry registry)
    {
        _registry = registry;
    }

    public IReadOnlyList<ModuleLoadResult> LoadModules(
        string modulesRoot,
        Version hostVersion)
    {
        var results = new List<ModuleLoadResult>();

        if (!Directory.Exists(modulesRoot))
        {
            Directory.CreateDirectory(modulesRoot);
            return results;
        }

        foreach (var moduleDirectory in Directory
                     .EnumerateDirectories(modulesRoot)
                     .OrderBy(path => path, StringComparer.OrdinalIgnoreCase))
        {
            results.Add(LoadModule(moduleDirectory, hostVersion));
        }

        return results;
    }

    private ModuleLoadResult LoadModule(
        string moduleDirectory,
        Version hostVersion)
    {
        ModuleManifest? manifest = null;

        try
        {
            var manifestPath = Path.Combine(moduleDirectory, "module.json");

            if (!File.Exists(manifestPath))
            {
                return Failure(
                    moduleDirectory,
                    null,
                    "module.json fehlt.");
            }

            manifest = ReadManifest(manifestPath);

            ValidateManifest(manifest, hostVersion);

            if (!manifest.Enabled)
            {
                return Failure(
                    moduleDirectory,
                    manifest.Id,
                    "Modul ist deaktiviert.");
            }

            var assemblyPath = Path.GetFullPath(
                Path.Combine(moduleDirectory, manifest.Assembly));

            if (!assemblyPath.StartsWith(
                    Path.GetFullPath(moduleDirectory),
                    StringComparison.Ordinal))
            {
                throw new InvalidDataException(
                    "Der Assembly-Pfad liegt außerhalb des Modulverzeichnisses.");
            }

            if (!File.Exists(assemblyPath))
            {
                throw new FileNotFoundException(
                    $"Modul-Assembly wurde nicht gefunden: {manifest.Assembly}",
                    assemblyPath);
            }

            var loadContext = new ModuleLoadContext(assemblyPath);
            var assembly = loadContext.LoadFromAssemblyPath(assemblyPath);

            var moduleTypes = assembly
                .GetTypes()
                .Where(type =>
                    !type.IsAbstract
                    && !type.IsInterface
                    && typeof(IToolModule).IsAssignableFrom(type))
                .ToArray();

            if (moduleTypes.Length != 1)
            {
                throw new InvalidOperationException(
                    $"Es wurde genau ein IToolModule erwartet, gefunden: {moduleTypes.Length}.");
            }

            if (Activator.CreateInstance(moduleTypes[0]) is not IToolModule module)
            {
                throw new InvalidOperationException(
                    "Das Modul konnte nicht erstellt werden.");
            }

            if (!string.Equals(
                    module.Id,
                    manifest.Id,
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException(
                    $"Manifest-ID '{manifest.Id}' und Modul-ID '{module.Id}' stimmen nicht überein.");
            }

            _registry.Register(module);
            _loadContexts.Add(loadContext);

            return new ModuleLoadResult(
                moduleDirectory,
                manifest.Id,
                true,
                $"{manifest.Name} {manifest.Version} geladen.");
        }
        catch (Exception exception)
        {
            return Failure(
                moduleDirectory,
                manifest?.Id,
                exception.Message);
        }
    }

    private static ModuleManifest ReadManifest(string manifestPath)
    {
        var json = File.ReadAllText(manifestPath);

        return JsonSerializer.Deserialize<ModuleManifest>(json)
               ?? throw new InvalidDataException(
                   "module.json konnte nicht gelesen werden.");
    }

    private static void ValidateManifest(
        ModuleManifest manifest,
        Version hostVersion)
    {
        if (string.IsNullOrWhiteSpace(manifest.Id))
        {
            throw new InvalidDataException("Modul-ID fehlt.");
        }

        if (string.IsNullOrWhiteSpace(manifest.Name))
        {
            throw new InvalidDataException("Modulname fehlt.");
        }

        if (string.IsNullOrWhiteSpace(manifest.Assembly))
        {
            throw new InvalidDataException("Assembly-Angabe fehlt.");
        }

        if (manifest.ApiVersion != SupportedApiVersion)
        {
            throw new InvalidDataException(
                $"API-Version {manifest.ApiVersion} wird nicht unterstützt. "
                + $"Unterstützt wird Version {SupportedApiVersion}.");
        }

        if (!Version.TryParse(
                manifest.MinimumHostVersion,
                out var minimumHostVersion))
        {
            throw new InvalidDataException(
                "minimumHostVersion ist ungültig.");
        }

        if (hostVersion < minimumHostVersion)
        {
            throw new InvalidDataException(
                $"Das Modul benötigt mindestens Host-Version {minimumHostVersion}.");
        }

        if (!Version.TryParse(manifest.Version, out _))
        {
            throw new InvalidDataException(
                "Modulversion ist ungültig.");
        }
    }

    private static ModuleLoadResult Failure(
        string moduleDirectory,
        string? moduleId,
        string message)
    {
        return new ModuleLoadResult(
            moduleDirectory,
            moduleId,
            false,
            message);
    }
}
